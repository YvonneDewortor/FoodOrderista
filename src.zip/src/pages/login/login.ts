import { Component } from "@angular/core";
import {
  IonicPage,
  NavController,
  LoadingController,
  Platform,
  AlertController,
  Events
} from "ionic-angular";
import { CustomValidators } from "ng2-validation";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { AngularFireAuth } from "@angular/fire/auth";
import { AngularFireDatabase } from "@angular/fire/database";
import { Facebook } from "@ionic-native/facebook";
import * as firebase from "firebase";
import { GooglePlus } from "@ionic-native/google-plus";

@IonicPage()
@Component({
  selector: "page-login",
  templateUrl: "login.html",
  providers: [GooglePlus]
})
export class LoginPage {
  tagHide: boolean = true;
  valForm: FormGroup;

  constructor(
    public navCtrl: NavController,
    public fb: FormBuilder,
    public af: AngularFireAuth,
    public db: AngularFireDatabase,
    public googlePlus: GooglePlus,
    public loadingCtrl: LoadingController,
    public alertCtrl: AlertController,
    public platform: Platform,
    public events: Events
  ) {
    this.valForm = fb.group({
      email: [
        "yvonnedewortor@gmail.com",
        Validators.compose([Validators.required, CustomValidators.email])
      ],
      password: ["ellen1999", Validators.required]
    });
  }

  toggleRegister() {
    this.tagHide = this.tagHide ? false : true;
  }

  OnLogin($ev, value: any) {
    $ev.preventDefault();
    for (let c in this.valForm.controls) {
      this.valForm.controls[c].markAsTouched();
    }
    if (this.valForm.valid) {
      this.af.auth.signInWithEmailAndPassword(value.email, value.password).then((success: any) => {
        localStorage.setItem("uid", success.uid);
        this.publishEvent();
        this.navCtrl.setRoot("HomePage");
      }).catch(error => {
        this.showAlert(error.message);
      });
    }
  }

  private publishEvent() {
    this.db.object("/users/" + this.af.auth.currentUser.uid).valueChanges().subscribe((userInfo: any) => {
      this.events.publish("imageUrl", userInfo);
    });
  }

  showAlert(message) {
    let alert = this.alertCtrl.create({
      subTitle: message,
      buttons: ["OK"]
    });
    alert.present();
  }

  Register() {
    this.navCtrl.setRoot("RegistrationPage");
  }

}
