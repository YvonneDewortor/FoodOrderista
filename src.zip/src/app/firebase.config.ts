export const firebaseConfig = {
  apiKey: "AIzaSyDplTjmNP814snP59wBrBedBj-exl2jhaU",
  authDomain: "foodorderista-31ad4.firebaseapp.com",
  databaseURL: "https://foodorderista-31ad4.firebaseio.com",
  projectId: "foodorderista-31ad4",
  storageBucket: "foodorderista-31ad4.appspot.com",
  messagingSenderId: "575506665823",
  appId: "1:575506665823:web:2f0387cd216f5b1d5c66ea",
  measurementId: "G-RS7EDXQ2ZT"
};
